const express = require('express');
const app = express();
const path = require('path');
// Configurando o Express para usar arquivos estáticos (HTML, CSS, JavaScript)
app.use(express.static(path.join(__dirname, 'public')));
// Rota para a página inicial
app.get('/', (req, res) => {
res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// Rota para a soma
app.get('/somar', (req, res) => {

// Recuperando os números enviados pelo formulário
const idade1 = parseInt(req.query.idade1);
const idade2 = parseInt(req.query.idade2);
const idade3 = parseInt(req.query.idade3);
// Realizando a soma
const resultado = idade1 + idade2 + idade3;
// Enviando o resultado como resposta
res.send(`A soma de ${idade1}, ${idade2} e ${idade3} é ${resultado}`);
});
app.get('/contar',(req, res) => {
    const numidades = [];
    numidades[0] = req.query.idade1;
    numidades[1] = req.query.idade2;
    numidades[2] = req.query.idade3;
    let length = numidades.length; 
    res.send(`A quantidade de idades colocada foi de ${length}`);
});

app.get('/medir',(req, res) => {

    if(idade1>idade2&&idade3){
        res.send(`A maior idade foi a Idade 1`);
    }else{
        if(idade2>idade1&&idade3){
        res.send(`A maior idade foi a Idade 2`);  
        }else{
        res.send(`A maior idade foi a Idade 3`);  
        }
    }

});

// Iniciando o servidor na porta 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
